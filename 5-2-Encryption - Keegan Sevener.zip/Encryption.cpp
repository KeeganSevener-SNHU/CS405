//=============================================================================
// Name        : Encryption.cpp
// Author      : Keegan Sevener
// Date        : June 3, 2025
// Class       : SNHU CS 405 - Secure Coding
// Description : 5-2 Activity: XOR Encryption
//=============================================================================

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
  // get lengths now instead of calling the function every time.
  // this would have most likely been inlined by the compiler, but design for perfomance.
  const auto key_length = key.length();
  const auto source_length = source.length();

  // assert that our input data is good
  assert(key_length > 0);
  assert(source_length > 0);

  std::string output = source;

  // loop through the source string char by char
  for (size_t i = 0; i < source_length; ++i) { 
    // FIXED: student needs to change the next line from output[i] = source[i]
    // transform each character based on an xor of the key modded constrained to key length using a mod
    output[i] = source[i] ^ key[i % key_length];
  }

  // our output length must equal our source length
  assert(output.length() == source_length);

  // return the transformed string
  return output;
}

std::string read_file(const std::string& filename)
{
  std::string file_text = ""; //= "John Q. Smith\nThis is my test string"

  // FIXED: implement loading the file into a string
  std::ifstream file(filename);

  // Make sure the file is open
  if (!file.is_open()) {
      std::cerr << "Error opening the file.";
      return "Error opening file";
  }
  // Second string for loop
  std::string str;

  // Add text to file_text
  while (std::getline(file, str)) {
      file_text = file_text + str + "\n";
  }

  // Close file.
  file.close();
  return file_text;
}

std::string get_student_name(const std::string& string_data)
{
  std::string student_name;

  // find the first newline
  size_t pos = string_data.find('\n');
  // did we find a newline
  if (pos != std::string::npos)
  { // we did, so copy that substring as the student name
    student_name = string_data.substr(0, pos);
  }

  return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
  //  FIXED: implement file saving
  //  file format
  //  Line 1: student name
  //  Line 2: timestamp (yyyy-mm-dd)
  //  Line 3: key used
  //  Line 4+: data

    std::ofstream file;

    // Open file and check if file opened successfully
    file.open(filename);
    if (!file.is_open()) {
        std::cerr << "Error creating the file.";
        return;
    }


    // Get current date
    time_t timestamp = time(NULL);
    struct tm datetime;
    localtime_s(&datetime, &timestamp);
    

    // Format the date.
    char formattedDate[50];
    strftime(formattedDate, 50, "%Y-%m-%d", &datetime);


    // Add data to file and close it.
    file << student_name << std::endl << formattedDate << std::endl << key << std::endl << data;
    file.close();
}

int main() {

  std::cout << "Encyption Decryption Test!" << std::endl;

  /*
  * Keegan Alexander Sevener
  * https://cupcakeipsum.com/
  * Jujubes drag�e carrot cake oat cake dessert jelly. Icing apple pie pastry caramels liquorice lemon drops danish croissant. Muffin lemon drops marzipan pastry carrot cake. Jelly beans shortbread chocolate bar lemon drops caramels gingerbread. Carrot cake topping marzipan chocolate bar gingerbread jelly-o cake. Tootsie roll chocolate cake wafer candy canes cookie cookie. Pudding marzipan candy pudding candy cake marzipan cake jelly. Bear claw cookie macaroon powder jelly beans gummies tart marzipan halvah. Candy ice cream muffin wafer tart bear claw candy marshmallow.
  * Souffl� sweet carrot cake icing icing cheesecake sweet roll jelly-o. Pastry powder caramels cake souffl� powder. Candy pastry drag�e icing pudding sweet cake cupcake. Chupa chups jelly beans sweet roll lollipop tart toffee. Gummies marzipan cake powder pastry jelly-o marzipan. Chupa chups candy apple pie topping topping. Toffee sugar plum jelly beans marzipan fruitcake marzipan sweet roll.
  * Gummies apple pie jujubes chocolate cake lemon drops pie jelly-o. Toffee sweet roll cake jelly beans tootsie roll oat cake pudding. Tootsie roll bonbon donut macaroon lemon drops jelly-o carrot cake muffin jelly beans. Cake bonbon muffin topping chocolate bar topping. Donut jelly beans cake biscuit croissant chocolate cotton candy powder cotton candy. Marzipan tart jelly beans sesame snaps drag�e marshmallow pudding. Danish biscuit toffee sesame snaps marshmallow candy canes sweet caramels. Cotton candy cheesecake gummies bear claw souffl� sweet roll drag�e gummies candy. Marzipan apple pie cake cookie candy bear claw bear claw chocolate cake chocolate.
  */

  const std::string file_name = "KeeganDataFile.txt";
  const std::string encrypted_file_name = "encrypteddatafile.txt";
  const std::string decrypted_file_name = "decrytpteddatafile.txt";
  const std::string source_string = read_file(file_name);
  const std::string key = "password";

  // get the student name from the data file
  const std::string student_name = get_student_name(source_string);

  // encrypt sourceString with key
  const std::string encrypted_string = encrypt_decrypt(source_string, key);

  // save encrypted_string to file
  save_data_file(encrypted_file_name, student_name, key, encrypted_string);

  // decrypt encryptedString with key
  const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

  // save decrypted_string to file
  save_data_file(decrypted_file_name, student_name, key, decrypted_string);

  std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

  // students submit input file, encrypted file, decrypted file, source code file, and key used
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
